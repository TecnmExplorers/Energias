
<!DOCTYPE html>
<html lang="es-MX">
<head>

<title>TecNM | Tecnológico Nacional de México</title>
<meta charset="UTF-8">
<meta name="author" content="TecNM">
<meta name="description" content="Página del Tecnológico Nacional de México">
<meta name="keywords" content="TecNM, Instituto Tecnológico Nacional de México, Tec, Tecnológico Nacional de México, Universidad" />
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
<meta name="copyright" content="TecNM" />
<meta name="robots" content="ALL">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="img/tecnmicono.ico" />
<!--<meta http-equiv="cache-control" content="no-cache"/>-->

<link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
<link rel="stylesheet" href="assets/tether/tether.min.css">
<link rel="stylesheet" href="assets/socicon/css/styles.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


<!-- CSS -->

<link rel="stylesheet" href="assets/styles/iconos.css" />
<link rel="stylesheet" href="img/iconos/ico/style.css" />
<link rel="stylesheet" href="assets/styles/estilo-compresion.min.css" />
	
<link rel="stylesheet" href="assets/social-feed-plugin/jquery.socialfeed.css">
<link rel="stylesheet" href="assets/social-feed-plugin/style.css">
<link rel="stylesheet" href="assets/theme/css/style.css">
<link rel="preload" href="assets/mobirise/css/mbr-additional.css">
<link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">

<!-- Twitter -->
<script id='twitter-wjs' src='https://platform.twitter.com/widgets.js'></script>

<!-- SweeAlert 2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<!-- CSS Bootstrap -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	
<!-- CSS del carrusel -->
<link rel="stylesheet" href="assets/files/main/css/owl.carousel.min.css">
<link rel="stylesheet" href="assets/files/main/css/owl.theme.default.min.css">

<!-- Estilos de a galeria -->
<link rel="stylesheet" href="assets/files/main/css/bootstrap-image-gallery.min.css">

<!-- CSS ligthbox -->
<link rel="stylesheet" href="assets/files/main/css/featherlight.min.css">
	
<!-- Iconos con Font Awesome -->
<link rel="stylesheet" href="assets/files/main/css/fa-svg-with-js.css">
<link rel="stylesheet" href="assets/files/main/css/fontawesome-all.min.css"> <!-- Se agrega para poder usar las fuentes en el css -->
<link rel="stylesheet" href="assets/files/main/css/estilo-compresion.min.css"> 
<link rel="stylesheet" href="assets/files/main/css/jssorStyle.css">  

<!-- Estilo del menú blanco -->

<!-- Estilo del menú azul -->

<script src="js/jquery-1.7.2.js"></script>

<script src="carrusel/jquery-3.1.1.slim.min.js" ></script>
<script src="carrusel/tether.min.js" ></script>

<!-- JavaScripts -->
<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/jquery-migrate-1.2.1.min.js"></script>

<!-- Stylesheets -->
<link rel="stylesheet" href="css/misc.css">
<link rel="stylesheet" href="css/green-scheme.css">

<!-- Redes Sociales -->
<style>
caption {
    text-align: right !important;
    }

#carouselExampleIndicators{   
	padding-top: 60px !important;	
	padding-bottom: 60px !important;
	/*height: 200 !important;*/
}

#blog{
    margin-top: 0px !important;
	height: 200px !important;

}

#homeIntro{
	height: 350px !important;
	margin-top: 0px !important;
    margin-top: 0px !important;
}
		
	h1, h2, h3, h4, h5, h6 {
    /*color: #ffffff !important;*/
    font-family:'Montserrat-Regular' !important;
    ;
}

.thumb-post .overlay .overlay-inner {
    background: #1B396A !important;
    
}

.container {
    padding-top: 30px !important;
    padding-bottom: 30px !important;
    padding-left: 3px !important;
    padding-right: 3px !important;
}

	.page-title {
  color: white !important;
  font-family:'Montserrat-Medium' !important;
  font-size: 40px;
  font-weight: 800 !important;
}

.page-title-2 {
  color: white !important;
  font-family:'Montserrat-Medium' !important;
  font-size: 30px;
  font-weight: 200 !important;
}

	.post-blog .blog-content h3 a {
    
    font-size: 2rem !important;
    color: #1B396A !important;
    font-family: 'Montserrat-Medium' !important;
}
	.accordion-button {
    font-size: 2.2rem !important;
    color: #1B396A !important;
	font-family: 'Montserrat-Medium' !important;
    }
	
	* {
      font-family:'Montserrat-Medium';
    }
	#navmeyer{
		font-family:'Montserrat-Bold' ;
	}
	@font-face {
	font-family: 'Montserrat-Medium';
	src: url("fonts/Montserrat-Medium.ttf");
	}
	@font-face {
	font-family: 'Montserrat-Regular';
	src: url("fonts/Montserrat-Regular.ttf");
	}
	@font-face {
	font-family: 'Montserrat-Black';
	src: url("fonts/Montserrat-Black.ttf");
	}
	@font-face {
	font-family: 'Montserrat-BlackItalic';
	src: url("fonts/Montserrat-BlackItalic.ttf");
	}
	@font-face {
	font-family: 'Montserrat-Bold';
	src: url("fonts/Montserrat-BlackItalic.ttf");
	}
	@font-face {
	font-family: 'Montserrat-BoldItalic';
	src: url("fonts/Montserrat-BoldItalic.ttf");
	}

	.sticky-container{ 
		padding:0px; 
		margin:0px; 
		position:fixed; 
		right:-135px;
		top:230px; 
		width:210px; 
		z-index: 1100; 
	}
	
	/*.sticky-container:hover{ right:-135px;}*/
	.sticky li{
		list-style-type: none;
		background-color: transparent;
		color: #efefef;
		height: 43px;
		padding: 0px;
		margin: 0px 0px 1px 0px; 
		-webkit-transition: all 0.25s ease-in-out;
		-moz-transition: all 0.25s ease-in-out;
		-o-transition:all 0.25s ease-in-out; 
		transition: all 0.25s ease-in-out; 
		cursor: pointer;
	}
	
	.sticky li:hover{ background-color:#fff; }
	.sticky li:hover{ margin-left:-115px; }
	.sticky li img{ float:left; margin:5px 4px; margin-right:5px;}
	.sticky li p{ padding-top:5px; margin:0px; line-height:16px; font-size:11px; }
	.sticky li p a{ text-decoration:none; color:#000; }
	.sticky li p a:hover{ text-decoration: underline; }

	/*
	@media (min-width: 1200px){ .container { max-width: 1300px; } }
	@media (min-width: 1700px){ .container { max-width: 1900px; } }
	@media (min-width: 1500px){ .container { max-width: 1600px; } }
	@media (min-width: 1200px){ .container { margin-left: 0px; } }
	@media screen and (max-width: 400px){ img{ display: none; } }
	@media screen and (max-width: 1141px){ #pleca_2{ display: none; } }
	*/
	
	@media screen and (max-width: 1140px){ #pleca_2{ display: none; } }
</style>
	
<link href="css/noticarrusel/slick-theme.css" rel="stylesheet" />
<link href="css/noticarrusel/slick.css" rel="stylesheet" />

<!-- Estilo del carrucel -->
<style> 
	
	.slider {
		width: 85%;
		margin: 0px auto;
	}

	.sitios {
		width: 50%;
		margin: 0px auto;
	}

	.principal {
		width: 100%;
		/*height: 60vh;*/
		margin: 0px 0px;
		margin-bottom:0px;
	}

	.slick-slide {
		margin: 0px 0px;
	}

	.slick-slide img {
		width: 100%;
	}
	
		.anexo > .slick-prev:before { /* Flecha azul - lado izquierdo */
		background: url('images/flechas/izquierda_gris.png');
		background-size: contain;
		color: transparent;
	}
	
		.anexo > .slick-next:before { /* Flecha azul - lado derecho */
		background: url('images/flechas/derecha_gris.png');    
		background-size: contain;
		color: transparent;
	}
		
		#noticias > .slick-prev:before { /* Flecha azul - lado izquierdo */
		background: url('images/flechas/izquierda_azul.png');
		background-size: contain;
		color: transparent;
	}
	
		#noticias > .slick-next:before { /* Flecha azul - lado derecho */
		background: url('images/flechas/derecha_azul.png');    
		background-size: contain;
		color: transparent;
	}

	.slick-slide {
		transition: all ease-in-out .3s;
		opacity: 1;
	}
	
	.slick-active {
		opacity: 1;
	}

	.slick-current {
		opacity: 1;
	}
</style>

<link rel="stylesheet" type="text/css" href="css/jquery.snippet.css" />
<script src='js/jquery-1.7.2.js'></script>
<script  src='js/jquery.snippet.js'></script>

<script src="js/raphael-min.js"></script>

<!-- Google Analytics -->
<script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-150388898-1"></script>
<script>
	window.dataLayer = window.dataLayer || [];
	function gtag() { dataLayer.push(arguments); }
	gtag('js', new Date());

	gtag('config', 'UA-150388898-1');
</script>

<style>
	.carousel-item {
		width:100vw;
		height: 60vh;
		min-height: 10%;
		background-size: contain;
		background-position: center;
		background-repeat: no-repeat;
		background: round;
	}

	.card-columns .card {
		display: inline-block;
		width: 100%;
	}

	.card-img-top {
		width: 100%;
		height: 200px !important; 
		border-top-left-radius: calc(0.25rem - 1px);
		border-top-right-radius: calc(0.25rem - 1px);
	}

		@media (max-width: 400px) {
		.carousel-item  {            
			height: 30vh;            
		}
	}

	@media (max-width: 500px) {
		.carousel-item  {            
			height: 25vh;            
		}
	}
</style>

<style>
	html, body{
		margin:0; 
		padding:0; 
		width: 100%; 
		height: 100%; 
	}
	.contenido{
		width: 95%;
		margin: auto;
	}
	
	@media screen and (max-width: 550px) {
		#sin{ display: none; }
	}
</style>

<!-- Intereses -->
<style> img.interes{ width: 15%; border: 0px solid #000; } </style>

<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
<script>
$(document).ready(function() {
	setTimeout(function() {
		$(".noticias").fadeIn(50);
	},50);
});
$(document).ready(function() {
	setTimeout(function() {
		//$(".contenedor").fadeIn(10000);
		$(".redes").fadeIn(50);
	},3000);
});
$(document).ready(function() {
	setTimeout(function() {
		$(".footer").fadeIn(50);
	},2000);
});
$(document).ready(function() {
	setTimeout(function() {
		$(".titulo").fadeIn(50);
	},2000);
});
</script>

<style> div.text-rigth a{ color:#fff; } </style>
<style> /* Footer Gobernación */
#gobierno_mexico{ display: flex; }
		iframe{
			width: auto;
		}
	@media screen and (max-width: 800px) {
		
		h1,h2{
			font-size: 20px !important;
		}
		.row{
			width: 98%;
			margin: auto;
		}
		#col1cel{
			width: 30% !important;
		}
		#col2cel{
			width: 40% !important;
		}
		#col3cel{
			width: 30% !important;
		}
		 
		th,td{
			word-break: break-all;
		}
		#homeIntro {
			background-image: url(images/includes/homein1-cel.jpg);
		}
	}
</style>

<style>
	#ordn{ background-color: red; position: absolute; width: 100%; }
	#color_real{ background-color: #1B396A; color: #fff; }
</style>

<script>
	var enviando = false;
	function checkSubmit() {
		if (!enviando) {
			enviando = true;
			return true;
		}else{
			alert('Por favor espere...');
			return false;
		}
	}
</script>

<!-- Sub Menú -->
<link rel="stylesheet" href="css/bootnavbar.css">

<!-- Menú Fijo -->
<style>	
	#main_navbar,
	#main_navbar1,
	#main_navbar2{
		width: 100%;
	}
	#barraGobmx,
	.menuazul,
	.menublanco{
		position: fixed;
	}
	<!-- .menublanco{ top: 4.7%; z-index: 1001; } -->
	<!-- .menuazul{ top: 8.7%; z-index: 1000; } -->
	#barraGobmx{ top: 0px; z-index: 1001; }
	.menublanco{ top: 40px; z-index: 1001; }
	.menuazul{ top: 77px; z-index: 1000; }
	
	@media (max-width: 700px) {
		.menublanco{ top: 37px; }
		.menuazul{ top: 65px; }
	}
</style>
<script>
	posicionarMenu2();

	$(window).scroll(function() { posicionarMenu2(); });

	function posicionarMenu2() {
		var altura_del_header = $('#barraGobmx').outerHeight(true);
		var altura_del_menu_blanco = $('#main_navbar2').outerHeight(true);

		if($(window).scrollTop() >= altura_del_header){
			$('#main_navbar2').addClass('menublanco');
			$('.wrapper').css('margin-top', (altura_del_menu_blanco) + 'px');
		}else{
			$('#main_navbar2').removeClass('menublanco');
			//$('.wrapper').css('margin-top', '0');
		}
	}
	
	posicionarMenu();

	$(window).scroll(function() { posicionarMenu(); });

	function posicionarMenu() {
		var altura_del_menu_blanco = $('#main_navbar2').outerHeight(true);
		var altura_del_menu = $('#main_navbar').outerHeight(true);
		var altura_del_menu1 = $('#main_navbar1').outerHeight(true);

		if($(window).scrollTop() >= altura_del_menu_blanco){
			$('#main_navbar').addClass('menuazul');
			$('.wrapper').css('margin-top', (altura_del_menu) + 'px');
			$('#main_navbar1').addClass('menuazul');
			$('.wrapper').css('margin-top', (altura_del_menu1) + 'px');
		}else{
			$('#main_navbar').removeClass('menuazul');
			$('#main_navbar1').removeClass('menuazul');
			//$('.wrapper').css('margin-top', '0');
		}
	}
</script>

<!-- Menú Azul -->
<style>
	#main_navbar .dropdown-menu{ background-color: #1B396A; }
	/*#main_navbar .dropdown-menu li{ border-top: 1px solid #fff; border-left: 1px solid #fff; border-right: 1px solid #fff; }*/
	#main_navbar .dropdown-menu li:before{ background-color: #1B396A; }
	#main_navbar .dropdown-menu li:after{ background-color: #1B396A; }
	#main_navbar .dropdown-menu a{ color: #fff; }

	#main_navbar1 .dropdown-menu{ background-color: #1B396A; }
	/*#main_navbar .dropdown-menu li{ border-top: 1px solid #fff; border-left: 1px solid #fff; border-right: 1px solid #fff; }*/
	#main_navbar1 .dropdown-menu li:before{ background-color: #1B396A; }
	#main_navbar1 .dropdown-menu li:after{ background-color: #1B396A; }
	#main_navbar1 .dropdown-menu a{ color: #fff; }
</style>

<!-- Traductor -->
<script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script type="text/javascript">
function googleTranslateElementInit() {
	new google.translate.TranslateElement({
		pageLanguage: 'es',
		autoDisplay: false,
		gaTrack: true,
		gaId: 'wewe',
		layout: google.translate.TranslateElement.InlineLayout.SIMPLE
	}, 'google_translate_element');
}

function recarga() {
	window.location.reload();
}
</script>

<!-- Ingresos -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">

<!--CONTENIDO -->
<style>
	.acuerdos th, td {
    text-align: justify !important;
    
}
.container {
	/*width: 100%;
	padding-right: 5px;
	padding-left: 5px;*/
	margin-right: auto !important;
	margin-left: auto !important;
}
@media (min-width: 768px){
	.col-md-4 {
		flex: 0 0 33% !important;
		max-width: 33% !important;
	}
}
.post-blog {
		margin-bottom: 1px !important;
    	padding-bottom: 1px !important;
        border-bottom: none !important;
}
.archive-list-nodot{
	width: 55% !important;
	list-style-type: none;
}

th {
    background-color: #1B396A !important;
	color:#ffffff !important;
}
</style>

</head>

<body>
<div class='contenido' style='width: 100%; max-width: 1900px; margin: auto;'>

<!-- MENU GOBERNACIÓN -->
<nav class="navbar navbar-expand navbar-dark bg-dark fixed-top">
	
	<a class="navbar-brand" href="https://www.gob.mx/" target="_blank">
		<img src="https://framework-gb.cdn.gob.mx/landing/img/logoheader.svg" height="29" alt="Gobierno de México">
	</a>

	<div class="collapse navbar-collapse pl-5 pl-lx-0" id="navbarSupportedContent">
		<ul class="navbar-nav ml-auto">
			
			<li class="nav-item"> 
				<a class="nav-link active" href="https://www.gob.mx/gobierno" target="_blank">
					Gobierno 
				</a> 
			</li>
			
			<li class="nav-item"> 
				<a class="nav-link active" href="https://www.participa.gob.mx/" target="_blank"> 
					Participa 
				</a> 
			</li>
			
			<li class="nav-item"> 
				<a class="nav-link active" href="https://datos.gob.mx/" target="_blank"> 
					Datos
				</a> 
			</li>
			
			<li class="nav-item"> 
				<a class="nav-link active" href="https://www.gob.mx/busqueda" target="_blank"> 
					<span class="sr-only"> Búsqueda </span>
					<svg class="svg-inline--fa fa-search fa-w-16" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="search" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
						<path fill="currentColor" d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path></svg>
				</a> 
			</li>
			
		</ul>
	</div>
	
</nav>

<!-- Encabezado principal -->
<div class="u-noPaddingContainer contenedorGobierno">
	<div class="container-cabecera">
		
		<div class="row no-gutters">
			<div class="col-md-12" style="max-width:60%">
				<div class="d-inline-block ipnLogo-enlace">
					<a href="https://www.gob.mx/" target="_blank" id="pleca_1">
						<img loading='lazy' src="assets/files/main/img/pleca-gob1.png" alt="Gobierno de México" class="plecaGob gob">
					</a>
						<a href="https://www.gob.mx/sep" target="_blank" id="pleca_2">
						<img loading='lazy' src="assets/files/main/img/pleca-gob2.png" alt="Educación" class="plecaGob gob">
					</a>
					<a href="/"  id="pleca_3">
						<img loading='lazy' style="width:17%;height:auto; min-width:70px" src="assets/files/main/img/pleca_tecnm.jpg" alt="TecNM" class="plecaTECNM">
					</a>
				</div>
			</div>
		</div>
		
		<!-- Opciones de accesibilidad -->
		<div class="contenedorAccesibilidad" style="top: 5%;">  
			<div class="idiomas text-right">
				<a href="https://globalpage-prod.webex.com/join?surl=https%3A%2F%2Fsignin.webex.com%2Fcollabs%2F%23%2Fmeetings%2Fjoinbynumber%3FTrackID%3D%26hbxref%3D%26goid%3Dattend-meeting" title="Microsoft Teams" target="_blank">
					<img loading='lazy' style="height:8%;width:7%" src="images/banderas/microsoft_teams.png" alt="MT">
				</a>
				<a href="https://login.microsoftonline.com/?whr=tecnm.mx" title="Correo Institucional" target="_blank">
					<img loading='lazy' style="height:8%;width:7%" src="images/banderas/correo-icono.png" alt="Buzón">
				</a>
				<a href="pdf/Calendario_Academico_Ciclo_Escolar_2021-2022.pdf" title="Calendario Académico" target="_blank">
					<img loading='lazy' style="height:6%;width:7%" src="images/banderas/calendario-icono.png" alt="Calendario Académico">
				</a>
				
					<a href='?vista=TecNM_Virtual&a#googtrans(es|zh-CN)'>
						<img style='height:6%;width:6%' src='images/banderas/china-icono.png' title='Mandarín'
							alt='Idioma Mandarín'>
					</a>
					<a href='?vista=TecNM_Virtual&b#googtrans(es|en)'>
						<img style='height:6%;width:6%' src='images/banderas/usa-icono.png' title='Inglés'
							alt='Idioma Inglés'>
					</a>
					<a href='?vista=TecNM_Virtual&c#googtrans(es|fr)'>
						<img style='height:6%;width:6%' src='images/banderas/francia-icono.png' title='Francés'
							alt='Idioma Francés'>
					</a>
					<a href='?vista=TecNM_Virtual&d#googtrans(es|es)' class='mr-3'>
						<img style='height:6%;width:6%' src='images/banderas/mexico-icono.png' title='Español'
							alt='Idioma Español'>
					</a>
										<img loading='lazy' style="height:6%;width:6%;" title="Accesibilidad" src="images/banderas/ojo-icono.png" alt="Débil Visual" />
				
				<a class="btn--accesibilidad contraste">
					<svg  class="svg-inline--fa fa-adjust fa-w-16" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="adjust" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path  fill="#1B396A" d="M8 256c0 136.966 111.033 248 248 248s248-111.034 248-248S392.966 8 256 8 8 119.033 8 256zm248 184V72c101.705 0 184 82.311 184 184 0 101.705-82.311 184-184 184z" ><title>Contraste</title></path></svg><!-- <i class="fas fa-adjust"></i> -->
				</a>
				<a class="btn--accesibilidad aumentaLetra " title="Aumentar letra" style="color:#1B396A" >A+</a>
				<a class="btn--accesibilidad reduceLetra" title="Disminuir letra"  style="color:#1B396A">A-</a>
				<a class="btn--accesibilidad resetLetra" title="Restablecer tamaño"  style="color:#1B396A">A </a>
			</div>
		</div>

	</div>
</div>
		
<!-- Menú Azul PRINCIPAL -->
<nav class="navbar navbar-expand-xl navbar-dark" style='background-color: #1B396A;margin: 0;' >
	
<!-- <a class="navbar-brand" href="#">Navbar</a> -->

<!-- <span id="tecnmblanco" style="visibility:hidden; "> -->
	<!-- <img loading='lazy' alt="TecNM" style="max-height:50px;" src="images/LogoTecNM%20Blanco.png" /> -->
<!-- </span> -->

<button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent3"
	aria-controls="navbarSupportedContent3" aria-expanded="false" aria-label="Toggle navigation">
	<span class="navbar-toggler-icon"></span> Menú Principal
</button>

<div class="collapse navbar-collapse pl-5 pl-lx-0" id="navbarSupportedContent3">
	<ul class="navbar-nav mr-auto">
		
		<!-- <li class="nav-item active"> -->
			<!-- <a class="nav-link" href="#"> TecNM <span class="sr-only">(current)</span></a> -->
		<!-- </li> -->
		
		<div class='d-none d-lg-block' id="tecnmblanco" style="visibility:hidden; ">
			<img loading='lazy' alt="TecNM" style="width: 90px; height:auto;" src="images/LogoTecNM%20Blanco.png" />
		</div>
		
		<!--<li class="nav-item active">
			<a class="nav-link" href="\"> <span class="icon-home"></span></a>
		</li> -->
		
		<li class="nav-item dropdown">
			<a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Con&oacute;cenos
			</a>
			<ul class="dropdown-menu " aria-labelledby="navbarDropdown">
				<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/itver/historia"> Historia </a></li>
				<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/itver/mision-vision-valores"> Misi&oacute;n y <br>Visi&oacute;n </a></li>
				<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/itver/himno-y-escudo"> Himno y Escudo </a></li>
				<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/itver/directorio"> Directorio </a></li>
				
			</ul>
		</li>
		
		<li class="nav-item dropdown">
			<a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Admisi&oacute;n
		</a>
		<ul class="dropdown-menu " aria-labelledby="navbarDropdown">
			<li class="nav-item dropdown">
				<a class="dropdown-item" href="http://www.veracruz.tecnm.mx/index.php/enlaces/articulos/647-convocatorias-de-ingreso-a-posgrado-2021-1"> Convocatorias de <br>Ingreso a Posgrado <br>2021-2 </a>
			</li>
			<li class="nav-item dropdown">
				<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Convocatoria Nuevo <br>Ingreso Septiembre <br>2021 - Febrero <br>2022 </a>									
				<ul class="dropdown-menu " aria-labelledby="navbarDropdown1">
					<li><a class="dropdown-item" href="https://fichatec.veracruz.tecnm.mx/"> Registro en Fichatec </a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Convocatorias <br>Anteriores <br>Licenciatura </a>									
				<ul class="dropdown-menu " aria-labelledby="navbarDropdown1">
					<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/admision/convocatorias-anteriores/convocatoria-nuevo-ingreso-ago-dic-2020"> Convocatoria Nuevo <br>Ingreso Ago - Dic <br>2020 </a></li>
				</ul>
			</li>
			<li class="nav-item dropdown">
				<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Convocatorias <br>Anteriores <br>Posgrado </a>									
				<ul class="dropdown-menu " aria-labelledby="navbarDropdown1">
					<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/admision/convocatorias-anteriores-posgrado/convocatoria-de-ingreso-a-posgrado-agosto-2020"> Convocatoria de <br>Ingreso a Posgrado <br>Agosto 2020 </a></li>
				</ul>
			</li>
		</ul>
		</li>
		
		<li class="nav-item dropdown">
			<a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Oferta Educativa
			</a>
			<ul class="dropdown-menu " aria-labelledby="navbarDropdown">
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Oferta <br>Acad&eacute;mica </a>									
					<ul class="dropdown-menu " aria-labelledby="navbarDropdown1">
					<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/administracion/index.html"> Licenciatura en <br>Administraci&oacute;n </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/bioquimica/index.html"> Ingenieria <br>Bioqu&iacute;mica </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/electrica/index.html"> Ingenieria <br>El&eacute;ctrica </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/electronica/index.html"> Ingenieria <br>Electr&oacute;nica </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/industrial/index.html"> Ingenieria <br>Industrial </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/mecatronica/index.html"> Ingenieria <br>Mecatr&oacute;nica </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/mecanica/index.html"> Ingenieria <br>Mec&aacute;nica </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/sistemas/index.html"> Ingenieria en <br>Sistemas <br>Computacionales </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/quimica/index.html"> Ingenieria <br>Qu&iacute;mica </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/Enerren/index.html"> Ingenieria en <br>Energias <br>Renovables </a></li>
						<li><a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/gestion/index.html"> Ingenieria en <br>Gesti&oacute;n <br>Empresarial </a></li>
					</ul>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="?vista=Posgrados"> Coordinadores de <br>Licenciatura </a>
				</li>
			</ul>
		</li>
		
		<li class="nav-item dropdown">
			<a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Departamentos
			</a>
			<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="?vista=MiembrosSNI"> Direcci&oacute;n </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Subdirecci&oacute;n <br>Acad&eacute;mica<br> ITVeracruz </a>									
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/departamento-de-ciencias-economico-administrativas"> Departamento de <br>Ciencias Econ&oacute;mico<br> Administrativas </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/departamento-de-ciencias-basicas"> Departamento de <br>Ciencias B&aacute;sicas </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/desarrollo-academico"> Desarrollo <br>Acad&eacute;mico </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/division-de-estudios-profesionales"> Divisi&oacute;n de <br>Estudios <br>Profesionales </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/division-de-estudios-de-posgrados-e-investigacion"> Divisi&oacute;n de <br>Estudios de <br>Posgrado e <br>Investigaci&oacute;n </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/departamento-de-ingenieria-metal-mecanica"> Divisi&oacute;n de <br>Ingenier&iacute;a <br>Metal-Mec&aacute;nica </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/departamento-de-ingenieria-electrica-electronica"> Divisi&oacute;n de <br>Ingenier&iacute;a <br>Electrico-Electr&oacute;nica </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/departamento-de-ingenieria-industrial"> Divisi&oacute;n de <br>Ingenier&iacute;a <br>Industrial </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/departamento-de-ingenieria-quimica-bioquimica"> Divisi&oacute;n de <br>Ingenier&iacute;a <br>Quimica-Bioqu&iacute;mica </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-academica-itveracruz/departamento-de-ingenieria-en-sistemas-y-computacion"> Divisi&oacute;n de <br>Ingenier&iacute;a en Sistemas <br>y Computaci&oacute;n </a></li>
					</ul>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Subdirecci&oacute;n de <br>Servicios <br>Administrativos </a>									
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-servicios-administrativos/recursos-materiales-y-servicios"> Recursos Materiales <br>y Servicios </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-servicios-administrativos/recursos-humanos"> Recursos <br>Humanos </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-servicios-administrativos/recursos-financieros"> Recursos <br>Financieros </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-servicios-administrativos/centro-de-computo"> Centro de <br>C&oacute;mputo </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-servicios-administrativos/departamento-de-mantenimiento-y-equipo"> Departamento de <br>Mantenimiento <br>y Equipo </a></li>
					</ul>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Subdirecci&oacute;n de <br>Planeaci&oacute;n y <br>Vinculaci&oacute;n <br>ITVeracruz </a>									
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-planeacion-y-vinculacion-itveracruz/departamento-de-planeacion-programacion-y-presupuestacion"> Departamento de <br>Planeaci&oacute;n Programaci&oacute;n <br>y Presupuestaci&oacute;n </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-planeacion-y-vinculacion-itveracruz/servicios-escolares"> Servicios <br>Escolares </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-planeacion-y-vinculacion-itveracruz/gestion-tecnologica-y-vinculacion"> Gesti&oacute;n <br>Tecnol&oacute;gica y <br>Vinculaci&oacute;n </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-planeacion-y-vinculacion-itveracruz/departamento-de-comunicacion-y-difusion"> Departamento de <br>Gesti&oacute;n y <br>Difusi&oacute;n </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-planeacion-y-vinculacion-itveracruz/centro-de-informacion"> Centro de <br>Informaci&oacute;n </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-planeacion-y-vinculacion-itveracruz/departamento-de-actividades-extraescolares"> Departamento de <br>Actividades <br>Extraescolares </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/subdireccion-de-planeacion-y-vinculacion-itveracruz/representante-de-la-direccion-sgc"> Responsable de <br>los Sistemas de <br>Gesti&oacute;n </a></li>
					</ul>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/organigrama/organigrama"> Organigrama </a>
				</li>

			</ul>
		</li>

		<li class="nav-item dropdown">
			<a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Normateca
			</a>
			<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Documentos <br>Operativos </a>									
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/documentos-operativos/inicio-normateca"> Inicio <br>Normateca </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/documentos-operativos/leyes"> Leyes </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/documentos-operativos/reglamentos"> Reglamentos </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/documentos-operativos/manuales"> Manuales </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/documentos-operativos/diversos"> Diversos </a></li>
						<li><a class="dropdown-item" href="http://online.fliphtml5.com/eujci/rrls/"> Informe de Rendici&oacute;n <br>de Cuentas Dic 2012 <br>Nov 2018 </a></li>
						<li><a class="dropdown-item" href="http://online.fliphtml5.com/eujci/tmqy/"> Informe de Rendici&oacute;n <br>de Cuentas 2018 (anual) </a></li>
						<li><a class="dropdown-item" href="https://online.fliphtml5.com/adgbx/wwss/"> Informe de Rendici&oacute;n <br>de Cuentas 2019 </a></li>
						<li><a class="dropdown-item" href="https://online.fliphtml5.com/vfxmd/ddib/4"> Informe de Rendici&oacute;n <br>de Cuentas 2020 </a></li>
					</ul>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://se.itver.edu.mx/"> Documentos de <br>Servicios Escolares </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/documentos-de-division-de-estudios-profesionales"> Documentos de <br>Divisi&oacute;n de Estudios <br>Profesionales </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/documentos-de-planeacion-programacion-y-presupuestacion"> Documentos de Planeaci&oacute;n, <br>Programaci&oacute;n y <br>Presupuestaci&oacute;n </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://se.itver.edu.mx/"> Documentos de <br>Servicios <br>Escolares </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Contralor&iacute;a <br>Social </a>									
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li class="nav-item dropdown">
							<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Contralor&iacute;a <br>2020 </a>									
							<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
								<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/contraloria-social/contraloria-social-2020/caracteristicas-generales-de-los-apoyos-tipo-monto-periodo-de-ejecucion-y-fecha-de-entrega"> Caracter&iacute;sticas <br>Generales de los <br>Apoyos (tipo, monto, <br>periodo de ejecuci&oacute;n y <br>fecha de entrega) </a></li>
								<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/contraloria-social/contraloria-social-2020/estructura-operativa-del-programa"> Estructura <br>Operativa del <br>Programa </a></li>
								<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/contraloria-social/contraloria-social-2020/para-alguna-queja-o-denuncia-interpuesta-debera-de-realizar-el-siguiente-procedimiento"> Para alguna <br>Queja o Denuncia <br>interpuesta deber&aacute; <br>realizar el siguiente <br>procedimineto </a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Sistema de Igualdad <br>Laboral y No <br>Discriminaci&oacute;n </a>									
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/sistema-de-igualdad-laboral-y-no-discriminacion/politica-de-igualdad-laboral-y-no-discriminacion-del-tecnologico-nacional-de-mexico"> Pol&iacute;tica de <br>Igualdad Laboral y <br>No Discriminaci&oacute;n del <br>Tecnol&oacute;gico Nacional <br>de M&eacute;xico </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/sistema-de-igualdad-laboral-y-no-discriminacion/codigo-de-etica-de-las-personas-servidoras-publicas-del-gobierno-federal"> C&Oacute;DIGO DE &Eacute;TICA <br>DE LAS PERSONAS <br>SERVIDORAS P&Uacute;BLICAS <br>DEL GOBIERNO <br>FEDERAL </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/sistema-de-igualdad-laboral-y-no-discriminacion/codigo-de-conducta-del-tecnm"> C&oacute;digo de <br>conducta del <br>TecNM </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/sistema-de-igualdad-laboral-y-no-discriminacion/acuerdo-de-igualdad-entre-mujeres-y-hombres"> Acuerdo de <br>Igualdad entre <br>Mujeres y <br>Hombres </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/sistema-de-igualdad-laboral-y-no-discriminacion/circular-en-materia-de-derechos-humanos-con-relacion-al-derecho-fudamental-a-la-no-discriminacion-y-al-principio-de-igualdad-con-respecto-a-la-operacion-y-funcionamiento-de-los-institutos-unidades-y-centros-adcritos-al-tecnologico-nacional-de-mexico"> Circular en <br>Materia de Derechos <br>Humanos con Relaci&oacute;n <br>al derecho fudamental <br>a la No Discriminaci&oacute;n <br>y al Principio <br>de Igualdad </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/sistema-de-igualdad-laboral-y-no-discriminacion/comite-de-etica-y-prevencion-de-conflictos-de-interes"> Comit&eacute; de <br>&Eacute;tica y Prevenci&oacute;n <br>de Conflictos de <br>Inter&eacute;s </a></li>
						<li><a class="dropdown-item" href="http://www.veracruz.tecnm.mx/index.php/enlaces/blog-notitec/402-nuevos-integrantes-de-subcomite-de-etica-y-prevencion-de-conflictos-de-interes-del-instituto-tecnologico-de-veracruz-itver"> Nuevos integrantes <br>de Subcomit&eacute; <br>de &eacute;tica y prevenci&oacute;n <br>de conflictos de <br>interés del Instituto <br>Tecnol&oacute;gico de <br>Veracruz (ITVER) </a></li>
						<li><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/normateca/sistema-de-igualdad-laboral-y-no-discriminacion/protocolo-de-actuacion"> PROTOCOLO DE <br>ACTUACI&Oacute;N </a></li>
					</ul>
				</li>
			</ul>
		</li>

		<li class="nav-item dropdown">
			<a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Enlaces
			</a>
			<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://login.microsoftonline.com/login.srf?lc=3082"> Correo <br>Institucional </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://sii.veracruz.tecnm.mx/"> SII Sistema <br>Integral de <br>Informaci&oacute;n </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/servicios-escolares"> Servicios <br>Escolares </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://gestion.itver.edu.mx/"> Gesti&oacute;n <br>Tecnol&oacute;gica y <br>Vinculaci&oacute;n </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://elearning.veracruz.tecnm.mx/"> Sistema Moodle <br>ITVeracruz </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://sgc.veracruz.tecnm.mx/"> Sistema de <br>Gesti&oacute;n </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog-notitec"> Blog Notitec </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://www.veracruz.tecnm.mx/index.php/enlaces/blog/radiotec-2019"> Radiotec TV </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/articulos"> Noticias</a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Impulso <br>Tecnol&oacute;gico </a>
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li class="nav-item dropdown"><a class="dropdown-item" href="http://www.veracruz.tecnm.mx/images/Imagenes/impulsotecnologico/html5forpc.html"> Impulso <br>Tecnol&oacute;gico 01 <br>2018 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="http://www.veracruz.tecnm.mx/images/Imagenes/IMPULSO_TECNOLOGICO_2/html5forpc.html"> Impulso <br>Tecnol&oacute;gico 02 <br>2018 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="http://www.veracruz.tecnm.mx/images/Imagenes/impulsotecnologico202001/html5forpc.html"> Impulso <br>Tecnol&oacute;gico 03 <br>2019</a></li>
						<li class="nav-item dropdown">
							<a class="dropdown-item dropdown-toggle" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Impulso <br>Tecnol&oacute;gico 03 <br>2019</a>
							<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown2">
								<li class="nav-item dropdown"><a class="dropdown-item" href="https://drive.google.com/file/d/1YaviAqPYAikZdVFjUIGIGJtw11nL_Ggz/view?usp=sharing" target="_blank"> Descargar PDF </a></li>
							</ul>
						</li>
						<li class="nav-item dropdown">
							<a class="dropdown-item dropdown-toggle" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Impulso <br>Tecnol&oacute;gico 04 <br>2020</a>
							<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown2">
								<li class="nav-item dropdown"><a class="dropdown-item" href="https://drive.google.com/file/d/1BS93I0lAxjDZ6tts7NvWPNQFYnwZ5A-c/view?usp=sharing" target="_blank"> Descargar PDF </a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item dropdown-toggle" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Blog </a>									
					<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown1">
						<li class="nav-item dropdown">
							<a class="dropdown-item dropdown-toggle" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Articulos </a>									
							<ul class="dropdown-menu sub-menu" aria-labelledby="navbarDropdown2">
								<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/articulos/actividades-deportivas" target="_blank"> Actividades <br>Deportivas </a></li>
								<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/articulos/actividades-culturales" target="_blank"> Actividades <br>Culturales </a></li>
								<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/articulos/cursos-de-idiomas" target="_blank"> Cursos de <br>Idiomas </a></li>
							</ul>
						</li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/radiotec-2018"> Radiotec 2018 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/maestria-en-administracion"> Maestria en <br>Administraci&oacute;n </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/curso-sensory-science-2018"> Curso Sensory <br>Science 2018 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/prenacional-2018"> Prenacional 2018 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/convocatorias"> Convocatorias </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/home5-pagina-en-construccion"> home5 p&aacute;gina en <br>construcci&oacute;n </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/radiotec-2019"> Radiotec 2019 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/sgc"> SGC </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/blog/auditorio-ing-fermin-carrillo-hernandez"> Auditorio &quot; Ing. Ferm&iacute;n <br>Carrillo Hern&aacute;ndez &quot; </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="http://187.243.246.24:8080/redmine/login"> Gestor de <br>Proyectos <br>REDMINE </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/simposio-internacional-biodiversidad-plastico-y-alternativas-para-su-eliminacion"> Simposio Internacional <br>Biodiversidad, Plastico <br>y Alternativas para <br>su eliminaci&oacute;n </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/eneit-2019-evento-nacional-estudiantil-de-innovacion-tecnologica-2019-fase-regional"> Eneit 2019 <br>Evento Nacional <br>Estudiantil de <br>Innovaci&oacute;n Tecnol&oacute;gica <br>2019 Fase <br>Regional </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/veracruz2020"> veracruz2020 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/regreso-seguro"> Regreso Seguro </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/articulos-de-regreso-seguro"> Articulos de <br>Regreso Seguro </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/videos-curso-induccion-2021"> Videos Curso <br>Inducci&oacute;n 2021 </a></li>
						<li class="nav-item dropdown"><a class="dropdown-item" href="https://www.veracruz.tecnm.mx/index.php/enlaces/videos-curso-induccion-2021-todos"> Videos Curso <br>Inducci&oacute;n 2021 Todos </a></li>
					</ul>
				</li>
			</ul>
		</li>
		
		<li class="nav-item dropdown">
			<a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				Posgrado
			</a>
			<ul class="dropdown-menu" aria-labelledby="navbarDropdown">
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://unida.veracruz.tecnm.mx/"> Unidad de <br>Investigaci&oacute;n y <br>Desarrollo de <br>Alimentos (UNIDA) </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://unida.veracruz.tecnm.mx/index.php/maestriadoct/maestria1"> M.C. en Ingenieria <br>Bioqu&iacute;mica </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://meeyer.veracruz.tecnm.mx/#nogo"> M. en Eficiencia <br>Energética Energias <br>Renovables </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://carreras.veracruz.tecnm.mx/academico/masadmin/index.html"> Maestria en <br>Administraci&oacute;n </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://unida.veracruz.tecnm.mx/index.php/maestriadoct/doctorado-en-ciencias-en-alimentos"> D. en Ciencias <br>en Alimentos </a>
				</li>
				<li class="nav-item dropdown">
					<a class="dropdown-item" href="http://posgrado.bdelrio.tecnm.mx/index.php/doctorado-en-ciencias-ambientales"> Doctorado en <br>Ciencias Ambientales </a>
				</li>
			</ul>
		</li>
		
	</ul>
</div>

</nav>
<!-- Menú Azul MEEYER  -->
<nav class="navbar navbar-expand-xl navbar-dark" style='background-color: #666;margin: 0;' id="navmeyer">
<!-- <a class="navbar-brand" href="#">Navbar</a> -->
	   
    <!-- <span id="tecnmblanco" style="visibility:hidden; "> -->
        <!-- <img loading='lazy' alt="TecNM" style="max-height:50px;" src="images/LogoTecNM%20Blanco.png" /> -->
    <!-- </span> -->
    
    <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent2"
        aria-controls="navbarSupportedContent2" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span> Menú Principal
    </button>

    <div class="collapse navbar-collapse pl-5 pl-lx-0" id="navbarSupportedContent2">
        <ul class="navbar-nav mr-auto">
            
            <!-- <li class="nav-item active"> -->
                <!-- <a class="nav-link" href="#"> TecNM <span class="sr-only">(current)</span></a> -->
            <!-- </li> -->
            
            <div class='d-none d-lg-block' id="tecnmblanco" style="visibility:hidden; ">
                <img loading='lazy' alt="TecNM" style="width: 90px; height:auto;" src="images/LogoTecNM%20Blanco.png" />
            </div>
            
            <li class="nav-item active">
               <!-- <a class="nav-link" href="\"> <span class="icon-home"></span></a>-->
            </li> 
            <li class="nav-item dropdown">
                <a class="nav-link active font-weight-bold" href="index.php">
                    Inicio
                </a>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Conócenos
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li class="nav-item dropdown"><a class="dropdown-item" href="MEEyER_Lineas.php"> Líneas </a></li>
                    <li class="nav-item dropdown"><a class="dropdown-item" href="MEEyER_Objetivos.php"> Objetivos </a></li>
                    <li class="nav-item dropdown"><a class="dropdown-item" href="MEEyER_Perfil_Ing.php"> Perfil de Ingreso </a></li>
                    <li class="nav-item dropdown"><a class="dropdown-item" href="MEEyER_Perfil_Egr.php"> Perfil de Egreso </a></li>
                    <li class="nav-item dropdown"><a class="dropdown-item" href="MEEyER_Campo_Accion.php"> Campo de Acción </a></li>
                    <li class="nav-item dropdown"><a class="dropdown-item" href="MEEyER_Colab_Social.php"> Colaboración Social </a></li>
                    
                </ul>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Plan de Estudios
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Sintesis_de_Plan.php"> Síntesis del Plan de Estudios  </a>
                    </li>
                   <!-- <li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Sel_Aspirantes.php"> Proceso de Admisión </a>
                    </li>-->
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Permanencia.php"> Permanencia </a>
                    </li>		<li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Mapa_Ret.php"> Mapa Curricular </a>
                    </li>		<li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Asignaturas.php"> Asignaturas </a>
                    </li>
                </li>		<li class="nav-item dropdown">
                    <a class="dropdown-item" href="MEEyER_Ob_Grado.php"> Obtención de Grado </a>
                </li>
                
                </ul>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Estudiantes
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Cohorte_generacional .php"> Cohorte Generacional  </a>
                    </li>
                    
                </ul>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Núcleo Académico
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Docentes.php"> Docentes </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Tutorias.php"> Tutoría </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href="MEEyER_Prod_Academica.php"> Productividad Académica </a>
                    </li>
                    
                </ul>
            </li>
            
            <li class="nav-item dropdown">
            <a class="nav-link active dropdown-toggle font-weight-bold" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Convocatoria
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href="images/includes/convocatorias/actual/convocatoria MEEYER 2021-2 vf.pdf" target="_blank"> Convocatoria Actual</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="dropdown-item" href=""> Historial de Convocatoria </a>
                    </li>
                    
                </ul>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link active font-weight-bold" href="MEEyER_Contacto.php">
                    Contacto
                </a>
            </li>
                                
        </ul>
    </div>
    
</nav>	
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.css">
<link rel="stylesheet" href="css/covid-19.css">
<!-- CONTENIDO -->

<div class="first-widget parallax" id="blog">
	<div class="parallax-overlay">
		<div class="container pageTitle">
			<div class="row">
				<div class="col-md-12 col-sm-12 text-left">
					<h1 class="page-title">LÍNEAS DE INVESTIGACIÓN</h1>
					<h2 class="page-title-2">MAESTRÍA EN EFICIENCIA ENERGÉTICA Y ENERGÍAS RENOVABLES</h2>
				</div> <!-- /.col-md-12 -->
				
			</div> <!-- /.row -->
		</div> <!-- /.container -->
	</div> <!-- /.parallax-overlay -->
</div> <!-- /.pageTitle -->

<div class="container">
	<div class="row">

		<div class="col-md-12 blog-posts">
			<div class="row">
				<div class="col-md-12">
					<div class="post-blog">
						<div class="blog-image">
							<!--<a id="susten">
								<img src="images/includes/encabezado.jpg" alt="">
							</a>
							<a id="susten">
								<img src="images/includes/Lineas/lineas.jpg" alt="">
							</a>-->
							<div class="accordion accordion-flush" id="accordionFlushExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingOne">
      <button id="flush-headingOne-b" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne" >
	  Sustentabilidad en sistemas energéticos
      </button>
    </h2>
    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body"><p align="justify">Desarrollar e implementar tecnologías y metodologías
								relativas a fuentes no convencionales de energía y la eficiencia en el consumo de
								energía eléctrica-
								térmica, que impacten significativamente en el sector productivo y social,
								procurando la disminución
								del impacto ambiental del uso de energéticos.</p>
							<p align="justify">La sustentabilidad, la eficiencia energética-ambiental y la seguridad
								son los tres elementos de
								integración establecidos en la Estrategia Nacional de Energía 2013-2027; la cual
								visualiza a la
								energía como un apoyo fundamental para el crecimiento económico y como un promotor
								del
								bienestar de la población. La línea de generación y aplicación del conocimiento
								busca contribuir
								directamente en las dos primeras estrategias antes mencionadas; debido a que
								contempla ser
								promotora del desarrollo e implementación de tecnologías y metodologías
								concernientes a fuentes no
								convencionales de energía, y de la eficiencia en el consumo de energía eléctrica y
								térmica. Dichos
								factores impactarán significativamente en el sector productivo y social; mejorando
								la competitividad,
								y el bienestar, disminuyendo el impacto ambiental del uso de energéticos con
								respecto a los medios
								más tradicionales. De manera indirecta también se contribuye con la estrategia de
								Seguridad, y esto
								es consecuencia de la disminución en la demanda de energéticos tradicionales, en las
								cuales
								normalmente hay una dependencia del exterior, y promoviendo la utilización de nuevas
								fuentes de
								energía provenientes de la localidad.</p> </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="flush-headingTwo">
      <button id="flush-headingTwo-b" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
	  Control de procesos energéticos
      </button>
    </h2>
    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
      <div class="accordion-body"><p align="justify">Desarrollar sistemas de control que permitan: disminuir los
								consumos de energía de equipos e incrementar la eficiencia energética de los
								procesos y otros
								aspectos del sector productivo y de servicios.</p>
							<p align="justify">El desarrollo tecnológico acelerado, unido al gran poder de
								procesamiento y velocidad que han
								alcanzado las computadoras, hace que hoy día sea prácticamente imposible concebir
								una actividad en
								cualquier proceso industrializado que no esté asociada a un equipo de control
								automático, y los
								procesos relacionados con el tema energético no son la excepción. Los sistemas de
								control de
								procesos son tan frecuentes y de tal magnitud, que obligan a estar permanentemente
								actualizado en
								Consciente de esta necesidad el Instituto Tecnológico de Veracruz ofrece la línea de
								Control de
								Procesos Energéticos, cuyo principal objetivo es capacitar a estudiantes y
								profesionales con los
								procedimientos, herramientas de software y hardware requeridas para el desarrollo
								del control de los
								procesos llevados en el sector energético.</p>
							<p align="justify">Esta línea de generación y aplicación del conocimiento le permitirá
								al alumno desarrollar una
								temática y un trabajo, que posteriormente le servirá como soporte a los programas de
								posgrado;
								definiendo nuevas rutas de investigación para diversos grupos y fortaleciendo los
								mismos con el
								desarrollo de proyectos de calidad. Además, el alumno contará con conocimientos que
								lo impulsarán
								en otras temáticas del área de la automatización industrial; generando que sean
								capaces de aplicar
								nuevos conocimientos e ideas, que conlleven al diseño y desarrollo de proyectos de
								reducido impacto
								ambiental, eficientes y dentro de las reglamentaciones de seguridad
								correspondientes.</p></div>
    </div>
  </div>
  
						
						</div> <!-- /.post-blog -->
				</div> <!-- /.col-md-12 -->
				<!--NO TOCAR -->

			</div> <!-- /.row -->
		</div> <!-- /.col-md-8 -->
		
		<!--<div class="col-md-4">
			<div class="sidebar">
				<div class="sidebar-widget">
					<h5 class="widget-title">Otros Enlaces</h5>
					<div class="last-post clearfix">
						<div class="thumb pull-left">
							<a href=""><img src="images/includes/tecnmlog.jpg" alt=""></a>
						</div>
						<div class="content">
							<span>Ir a</span>
							<h4><a href="http://tecnm.mx/">Sitio oficial del TecNM</a></h4>
						</div>
					</div>  /.last-post

					<div class="last-post clearfix">
						<div class="thumb pull-left">
							<a href=""><img src="images/includes/ITVlog.jpg" alt=""></a>
						</div>
						<div class="content">
							<span>Ir a</span>
							<h4><a href="http://www.itver.edu.mx/index.php/es/">Sitio oficial del ITVER</a></h4>
						</div>
					</div>  /.last-post 
				</div>  /.sidebar-widget 
				<div class="sidebar-widget">
					<h5 class="widget-title">MEEyER</h5>
					<div class="row categories">
						<div class="col-md-6">
							<ul>
								<li><a href="MEEyER - lineas.html">Líneas</a></li>
								<li><a href="MEEyER - objetivos.html">Objetivos</a></li>
								<li><a href="MEEyER - perfil in.html">Perfil de Ingreso</a></li>

							</ul>
						</div>
						<div class="col-md-6">
							<ul>
								<li><a href="MEEyER - perfil eg.html">Perfil de Egreso</a></li>
								<li><a href="MEEyER - c accion.html">Campo de Acción</a></li>
							</ul>
						</div>
					</div>  /.row 
				</div>  /.sidebar-widget -->

				<!--<div class="sidebar-widget">
					<h5 class="widget-title">Contacto</h5>
					<p><b>M.C. Carlos Roberto González Escarpeta</b></p>
					<p>Coordinador de la Maestría en Eficiencia Energética y Energías Renovables</p>
					<p><a>carlosge@itver.edu.mx</a></p>

					<p><b>Dr. Benigno Ortiz Muñiz</b></p>
					<p>Jefe de la División de Estudios de Posgrado e Investigación</p>
					<p><a>depi_veracruz@tecnm.mx</a></p>
					<p><a>posgrado@itver.edu.mx</a></p>

					<p><b>Teléfono</b></p>
					<p><b>229-934-1500 ext.</b> <a>110</a></p>

				</div>  /.sidebar-widget -->
			</div> <!-- /.sidebar -->
		</div> <!-- /.col-md-4 -->

	</div> <!-- /.row -->
</div> <!-- /.container -->
<script>
const queryString = window.location.search;

const urlParams = new URLSearchParams(queryString);

const page_type = urlParams.get('opt');
if(page_type == 1){
	document.getElementById('flush-headingOne-b').classList.remove("collapsed");
	document.getElementById('flush-collapseOne').classList.add("show");
	document.getElementById('flush-headingOne-b').ariaExpanded = "true";
}
if(page_type == 2){
	document.getElementById('flush-headingTwo-b').classList.remove("collapsed");
	document.getElementById('flush-collapseTwo').classList.add("show");
	document.getElementById('flush-headingTwo-b').ariaExpanded = "true";
}
</script>
<!--FIN DE CONTENIDO-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
	<script>
		baguetteBox.run('.tz-gallery');
	</script>	
	<!-- Menú lateral de Redes Sociales -->
    <div class="sticky-container">
		<ul class="sticky">
			<li>
				<img loading='lazy' src="images/redes_sociales/facebook.png" width="32" height="32" alt="facebook" />
				<p><a href="https://www.facebook.com/SomosTecNM/" target="_blank">Me gusta en<br>Facebook</a></p>
			</li>
			<li>
				<img loading='lazy' src="images/redes_sociales/twitter.png" width="32" height="32" alt="Twitter" />
				<p><a href="https://twitter.com/TecNM_MX" target="_blank">Síguenos en<br>Twitter</a></p>
			</li>
			<li>
				<img loading='lazy' src="images/redes_sociales/youtube.png" width="32" height="32" alt="YouTube" />
				<p><a href="https://www.youtube.com/user/SNESTMX" target="_blank">Suscríbase en<br>YouTube</a></p>
			</li>
		</ul>
	</div>
	
	<!-- Dirección y teléfono -->
		
	<div class='footer' style='display: none;'>
    <section class="cid-rD7PmpFJj8" id="footer2-7" style="padding-bottom:10px">
    <div class="">
        <div class="media-container-row content mbr-white">
            <div class="col-12 col-md-3 mbr-fonts-style display-7" style="font-family:Roboto,'Opens Sans', sans-serif" >
				<div class="custom">
					<p style="text-align: left;"><span style="color: #000000;"></span></p>
				<p style="text-align: left;"><span style="color: #ffffff;">Dirección:</span></p>
				<div class="floatright fp-contact" style="text-align: left;"><span style="color: #ffffff;"><strong><span style="color: #ffffff;">Tecnológico Nacional de México campus Veracruz&nbsp;</span>&nbsp; |&nbsp;&nbsp;<a style="color: #ffffff;" href="http://www.itver.edu.mx/">www.veracruz.tecnm.mx</a></strong></span></div>
				<div class="floatright fp-contact" style="text-align: left;"><span style="color: #ffffff;">© 2019 / Tecnológico Nacional de México Veracruz</span></div>
				<div class="floatright fp-contact" style="text-align: left;"><span style="color: #ffffff;">Calz. Miguel Angel de Quevedo 2779</span></div>
				<div class="floatright fp-contact" style="text-align: left;"><span style="color: #ffffff;">Col. Formando Hogar, Veracruz, Ver. MEXICO CP 91897</span></div>
				<div style="text-align: left;"><span style="color: #ffffff;"></span></div>
				<div style="text-align: left;"><span style="color: #ffffff;">Contacto:</span></div>
				<div class="floatright fp-contact" style="text-align: left;"><span style="color: #ffffff;">(229) 934 15 00</span></div>
				<div>&nbsp;</div>
				<div><span style="color: #ffffff;"><a style="color: #ffffff;" href="mailto:web_veracruz@tecnm.mx">web_veracruz@tecnm.mx</a></span></div>
				<div style="text-align: left;"><span style="color: #000000;"></span></div>
				<div style="text-align: left;"><span style="color: #ffffff;"></span></div>
				<div style="text-align: left;"><span style="color: #ffffff;"></span></div>
				<div style="text-align: left;"><span style="color: #ffffff;"></span></div></div>
				
            </div>
            <div class="contenedor">
				<!--<a href='?vista=Ubicacion' title='Ver Ubicación'>
					<img loading='lazy' src="images/footer/Foto_Ubicación.jpg" alt="Ubicación" style='width:95%;' />
				</a>-->
				<p align="center">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60297.580116847035!2d-96.19062131674059!3d19.169033180732956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85c34419964cc761%3A0xa6d7c54363cf608e!2sTecNM%20-%20Campus%20Instituto%20Tecnol%C3%B3gico%20de%20Veracruz!5e0!3m2!1ses!2smx!4v1630627315439!5m2!1ses!2smx" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
				</p>
			</div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white" style="font-family:Roboto,'Opens Sans', sans-serif">
                <div class="col-sm-6 copyright">
                    <center>
					<p class="mbr-text mbr-fonts-style display-7">
						© Copyright 2021  TecNM - Todos los Derechos Reservados
					</p>
                    <br />
                    <p class="mbr-text mbr-fonts-style display-7">
						<a href='https://www.gob.mx/cms/uploads/attachment/file/328462/Proyecto_Aviso_Privacidad_TecNM_16052018.pdf' target='_blank'>
							<span class='text-white'> Aviso de Privacidad </span>
						</a>
					</p>
					<br />
                    <p class="mbr-text mbr-fonts-style display-7">
						Última actualización: 31/08/2021
					</p>
					</center>
                </div>
            </div>
        </div>
    </div>
	</section>	
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/files/main/js/jquery-3.3.1.min.js"></script>
	<script src="assets/files/main/js/bootstrap.min.js"></script>
	<script src="assets/files/main/js/bootstrap-image-gallery.min.js"></script>
	<script src="assets/files/main/js/fontawesome-all.min.js"></script>
	<script src="assets/files/main/js/loader.js"></script>
	<script src="assets/files/main/js/owl.carousel.min.js"></script>
	<script src='assets/files/main/js/index.onload.js'></script>
	<script src="assets/files/main/js/featherlight.min.js"></script>
	
	<script src='assets/web/assets/jquery/jquery.min.js'></script>	
	
	<!-- Ordenamiento -->
	<script src='js/reordenamiento/jquery.min.js'></script>
	<script src='js/reordenamiento/jquery-ui.js'></script>
	
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	
	<!-- Facebook -->
	<script src='assets/facebook-plugin/facebook-script.js'></script>
	
	<script src="assets/smoothscroll/smooth-scroll.js"></script>
	<script src="assets/dropdown/js/nav-dropdown.js"></script>
	<script src="assets/dropdown/js/navbar-dropdown.js"></script>
	<script src="assets/tether/tether.min.js"></script>
	<script src="assets/parallax/jarallax.min.js"></script>
	<script src="assets/viewportchecker/jquery.viewportchecker.js"></script>
	<script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
	<script src="assets/social-feed-plugin/codebird.min.js"></script>
	<script src="assets/social-feed-plugin/moment.js"></script>
	<script src="assets/social-feed-plugin/en-gb.js"></script>
	<script src="assets/social-feed-plugin/doT.js"></script>
	<script src="assets/social-feed-plugin/jquery.socialfeed.js"></script>
	<script src="assets/social-feed-plugin/main.js"></script>
	<script src="assets/theme/js/script.js"></script>
	
	<script> /* Configuración de los carrucel */
		$(document).on('ready', function () {
		
			$('.one-time').slick({
              dots: true,
              infinite: true,
              speed: 500,
              slidesToShow: 1,
              adaptiveHeight: true,
              adaptiveWidth: true,
              autoplay: true,
              autoplaySpeed: 6000,
              arrows: false,
              fade: true,
              pauseOnHover: true
			});

			$('.center').slick({
              dots: false,
              infinite: true,
              arrows: true,
              autoplay: true,
              autoplaySpeed: 4000,
              centerMode: false,
              centerPadding: '0px',
              slidesToShow: 4,
              responsive: [{
                    breakpoint: 768,
                    settings: {
                        //arrows: false,
                        centerMode: true,
                        centerPadding: '0px',
                        slidesToShow: 2
                    }
                },{
                    breakpoint: 480,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '0px',
                        slidesToShow: 2
                    }
                }
              ]
			});

			$('.anexo').slick({
              dots: false, // puntos
              infinite: true, 
              arrows: true, // flechas
              autoplay: true,
              autoplaySpeed: 3500,
              slidesToShow: 4,
              pauseOnHover: true,
              responsive: [{
                    breakpoint: 768,
                    settings: {
                        //arrows: false,
                        slidesToShow: 2
                    }
                },{
                    breakpoint: 480,
                    settings: {
                        arrows: false,
                        centerPadding: '0px',
                        slidesToShow: 2
                    }
                }
              ]
			});
		});
	</script>
	
	<script src="js/noticarrusel/slick.js"></script>
    
	<!-- Ingresos -->
    <script src="js/ingresos/jquery.dataTables.min.js"></script>
	<script src="js/ingresos/funciones.js?key=1301658953"></script>    
	
	<!-- Footer Gobernación -->
	<!-- <script src='assets/gobmx/gobmx.js'></script> -->
		<div class='footer' style='display: none;'>
	<footer class="main-footer">
		<div class="list-info" id='gobierno_mexico'>
		<!-- <div class="row"> -->
			<div class="col-sm-3">
				<img loading='lazy' data-v-9e928f9a="" src="https://framework-gb.cdn.gob.mx/landing/img/logoheader.svg" href="/" alt="logo gobierno de méxico" class="logo_footer" style="width: 70%; max-width: 1000px;">
			</div>
			<div class="col-sm-3">
				<h5>Enlaces</h5>
				<ul>
					<li>
						<a href="https://participa.gob.mx" target="_blank" rel="noopener" title="Enlace abre en ventana nueva">Participa</a>
					</li>
					<li>
						<a href="https://www.gob.mx/publicaciones" target="_blank" rel="noopener" title="Enlace abre en ventana nueva">Publicaciones Oficiales</a>
					</li>
					<li>
						<a href="http://www.ordenjuridico.gob.mx" target="_blank" rel="noopener" title="Enlace abre en ventana nueva">Marco Jurídico</a>
					</li>
					<li>
						<a href="https://consultapublicamx.inai.org.mx/vut-web/" target="_blank" rel="noopener" title="Enlace abre en ventana nueva">Plataforma Nacional de Transparencia</a>
					</li>
				</ul>
			</div>
			<div class="col-sm-3">
				<h5>¿Qué es gob.mx?</h5>
				<p> Es el portal único de trámites, información y participación ciudadana. 
					<a href="https://www.gob.mx/que-es-gobmx" target="_blank">Leer más</a>
				</p>
			<ul>
			<li><a href="https://datos.gob.mx" target="_blank" >Portal de datos abiertos</a></li>
			<li><a href="https://www.gob.mx/accesibilidad" target="_blank">Declaración de accesibilidad</a></li>
			<li><a href="https://www.gob.mx/privacidadintegral" target="_blank">Aviso de privacidad integral</a></li>
			<li><a href="https://www.gob.mx/privacidadsimplificado" target="_blank">Aviso de privacidad simplificado</a></li>
			<li><a href="https://www.gob.mx/terminos" target="_blank">Términos y Condiciones</a></li>
			<li><a href="https://www.gob.mx/terminos#medidas-seguridad-informacion" target="_blank">Política de seguridad</a></li>
			<li><a href="https://www.gob.mx/sitemap" target="_blank">Mapa de sitio</a></li>
			</ul>
			</div>
			<div class="col-sm-3">
			<h5>
				<a href="https://www.gob.mx/tramites/ficha/presentacion-de-quejas-y-denuncias-en-la-sfp/SFP54" target="_blank">
					Denuncia contra servidores públicos
				</a>
			</h5>
			<h5> Síguenos en </h5>
			<ul class="list-inline">
				<li>
				<a class="social-icon facebook" target="_blank" rel="noopener" title="Enlace abre en ventana nueva" href="https://www.facebook.com/gobmexico" aria-label="Facebook de presidencia">
				</a>
				</li>
				<li>
					<a class="social-icon twitter" target="_blank" rel="noopener" title="Enlace abre en ventana nueva" href="https://twitter.com/GobiernoMX" aria-label="Twitter de presidencia">
					</a>
				</li>
			</ul>
			</div>
		<!-- </div> -->
		</div>
		<!--<div class="container-fluid footer-pleca"><div class="row"><div class="col"><br><br></div></div></div>-->
	</footer>
	</div>
  	
	<style>
		div.modal label{
			color: #315676;
			font-size: 1.0rem;
			font-weight: 600;
			margin-top: 3%;
		}
		
		div.modal input, 
		div.modal textarea,
		div.modal select{
			width:100%; 
			height: auto;
			border: 1px solid #000;
			padding: 2px;
		}
		
		div.modal textarea{
			height: 150px;
		}
		
		div.modal input.btn-primary{
			width: auto;
			padding: 1.5%;
		}
	</style>
	
	<!-- Modal -->
	<div class="modal fade" id="modalQuejas" role="dialog">
	<div class="modal-dialog">

		<div class="modal-content">
		<form name="new user" method="POST" action=""> 
			<div class="modal-header">
			  <h3 class="modal-title"> Sugerencias, Quejas y Felicitaciones </h3>
			</div>
			<div class="modal-body">
				<div>
					<label for='asunto'> Asunto: </label>
					<select name='asunto' id='asunto' required>
						<option value=''> Seleccione </option>
						<option value='Felicitación'> Felicitación </option>
						<option value='Queja'> Queja </option>
						<option value='Sugerencia'> Sugerencia </option>
					</select>
				</div>
				<div>
					<label for='nombre'> Nombre: </label>
					<input type='text' name='nombre' id='nombre' autocomplete='off' required />
				</div>
				<div>
					<label for='email'> Email: </label>
					<input type='email' name='correo' id='email' autocomplete='off' required />
				</div>
				<div>
					<label for='mensaje'> Mensaje: </label>
					<textarea name='mensaje' id='mensaje' required></textarea>
				</div>
			</div>
			<div class="modal-footer">
				<input type="submit" class="btn btn-primary" name='btn_mensaje' value='Enviar' />
				<button type="button" class="btn btn-default" data-dismiss="modal"> Cerrar </button>
			</div>
		</form>
		</div>

	</div>
	</div>
	
	</div>
	
	<!-- Menú -->
	<script src="js/bootnavbar.js"></script>
    <script>
        $(function () {
            $('#main_navbar').bootnavbar({
                //option
                //animation: false
            });
        })
    </script>
	
  </body>
</html>